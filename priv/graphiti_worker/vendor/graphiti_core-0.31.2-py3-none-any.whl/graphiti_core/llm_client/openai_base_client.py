"""
Copyright 2024, Zep Software, Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import json
import logging
import re
import typing
from abc import abstractmethod
from typing import Any, ClassVar

import openai
from openai.types.chat import ChatCompletionMessageParam
from pydantic import BaseModel

from ..prompts.models import Message
from .client import LLMClient, get_extraction_language_instruction
from .config import DEFAULT_MAX_TOKENS, LLMConfig, ModelSize
from .errors import RateLimitError, RefusalError

logger = logging.getLogger(__name__)

DEFAULT_MODEL = 'gpt-6-luna'
DEFAULT_SMALL_MODEL = 'gpt-6-luna'
# 'auto' is a sentinel meaning "pick a reasoning effort based on the model"
# (resolved by _resolve_reasoning_effort); it is never sent to the API.
DEFAULT_REASONING = 'auto'
DEFAULT_VERBOSITY = 'low'


class BaseOpenAIClient(LLMClient):
    """
    Base client class for OpenAI-compatible APIs (OpenAI and Azure OpenAI).

    This class contains shared logic for both OpenAI and Azure OpenAI clients,
    reducing code duplication while allowing for implementation-specific differences.
    """

    # Class-level constants
    MAX_RETRIES: ClassVar[int] = 2

    def __init__(
        self,
        config: LLMConfig | None = None,
        cache: bool = False,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        reasoning: str | None = DEFAULT_REASONING,
        verbosity: str | None = DEFAULT_VERBOSITY,
    ):
        if cache:
            raise NotImplementedError('Caching is not implemented for OpenAI-based clients')

        if config is None:
            config = LLMConfig()

        super().__init__(config, cache)
        self.max_tokens = max_tokens
        self.reasoning = reasoning
        self.verbosity = verbosity

    @abstractmethod
    async def _create_completion(
        self,
        model: str,
        messages: list[ChatCompletionMessageParam],
        temperature: float | None,
        max_tokens: int,
        response_model: type[BaseModel] | None = None,
    ) -> Any:
        """Create a completion using the specific client implementation."""
        pass

    @abstractmethod
    async def _create_structured_completion(
        self,
        model: str,
        messages: list[ChatCompletionMessageParam],
        temperature: float | None,
        max_tokens: int,
        response_model: type[BaseModel],
        reasoning: str | None,
        verbosity: str | None,
    ) -> Any:
        """Create a structured completion using the specific client implementation."""
        pass

    def _convert_messages_to_openai_format(
        self, messages: list[Message]
    ) -> list[ChatCompletionMessageParam]:
        """Convert internal Message format to OpenAI ChatCompletionMessageParam format."""
        openai_messages: list[ChatCompletionMessageParam] = []
        for m in messages:
            m.content = self._clean_input(m.content)
            if m.role == 'user':
                openai_messages.append({'role': 'user', 'content': m.content})
            elif m.role == 'system':
                openai_messages.append({'role': 'system', 'content': m.content})
        return openai_messages

    def _get_model_for_size(
        self,
        model_size: ModelSize,
        *,
        model: str | None = None,
    ) -> str:
        """Get the appropriate model name based on the requested size."""
        if model is not None:
            return model
        if model_size == ModelSize.small:
            return self.small_model or DEFAULT_SMALL_MODEL
        else:
            return self.model or DEFAULT_MODEL

    @staticmethod
    def _is_reasoning_model(model: str) -> bool:
        """Return True for o1/o3 models and GPT models with major version 5 or later."""
        if model.startswith(('o1', 'o3')):
            return True
        version = re.match(r'gpt-(\d+)', model)
        return version is not None and int(version.group(1)) >= 5

    @staticmethod
    def _prompt_cache_options(model: str) -> dict[str, str] | None:
        """gpt-6 writes prompts of 1,024+ tokens by default at 1.25x the input rate.

        Explicit mode without a breakpoint writes nothing. Other models reject the
        prompt_cache_options field.
        """
        return {'mode': 'explicit'} if model.startswith('gpt-6') else None

    @staticmethod
    def _resolve_reasoning_effort(model: str, reasoning: str | None) -> str | None:
        """Resolve the reasoning effort to send for a reasoning model.

        Auto selects ``'none'`` for GPT 5.1+ and later major versions. It selects
        ``'minimal'`` otherwise. Explicit values, including ``None``, pass through
        unchanged.
        """
        if reasoning != 'auto':
            return reasoning
        version = re.match(r'gpt-(\d+)(?:\.(\d+))?', model)
        if version is not None:
            major = int(version.group(1))
            minor = version.group(2)
            if major > 5 or (major == 5 and minor is not None and int(minor) >= 1):
                return 'none'
        return 'minimal'

    def _handle_structured_response(self, response: Any) -> tuple[dict[str, Any], int, int]:
        """Handle structured response parsing and validation.

        Returns:
            tuple: (parsed_response, input_tokens, output_tokens)
        """
        response_object = response.output_text

        # Extract token usage
        input_tokens = 0
        output_tokens = 0
        if hasattr(response, 'usage') and response.usage:
            input_tokens = getattr(response.usage, 'input_tokens', 0) or 0
            output_tokens = getattr(response.usage, 'output_tokens', 0) or 0

        if response_object:
            return json.loads(response_object), input_tokens, output_tokens
        elif hasattr(response, 'refusal') and response.refusal:
            raise RefusalError(response.refusal)
        else:
            raise Exception(f'Invalid response from LLM: {response}')

    def _handle_json_response(self, response: Any) -> tuple[dict[str, Any], int, int]:
        """Handle JSON response parsing.

        Returns:
            tuple: (parsed_response, input_tokens, output_tokens)
        """
        result = response.choices[0].message.content or '{}'

        # Extract token usage
        input_tokens = 0
        output_tokens = 0
        if hasattr(response, 'usage') and response.usage:
            input_tokens = getattr(response.usage, 'prompt_tokens', 0) or 0
            output_tokens = getattr(response.usage, 'completion_tokens', 0) or 0

        return json.loads(result), input_tokens, output_tokens

    async def _generate_response(
        self,
        messages: list[Message],
        response_model: type[BaseModel] | None = None,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        model_size: ModelSize = ModelSize.medium,
        *,
        model: str | None = None,
    ) -> tuple[dict[str, Any], int, int]:
        """Generate a response using the appropriate client implementation.

        Returns:
            tuple: (response_dict, input_tokens, output_tokens)
        """
        openai_messages = self._convert_messages_to_openai_format(messages)
        resolved_model = self._get_model_for_size(model_size, model=model)

        try:
            if response_model:
                response = await self._create_structured_completion(
                    model=resolved_model,
                    messages=openai_messages,
                    temperature=self.temperature,
                    max_tokens=max_tokens or self.max_tokens,
                    response_model=response_model,
                    reasoning=self.reasoning,
                    verbosity=self.verbosity,
                )
                return self._handle_structured_response(response)
            else:
                response = await self._create_completion(
                    model=resolved_model,
                    messages=openai_messages,
                    temperature=self.temperature,
                    max_tokens=max_tokens or self.max_tokens,
                )
                return self._handle_json_response(response)

        except openai.LengthFinishReasonError as e:
            raise Exception(f'Output length exceeded max tokens {self.max_tokens}: {e}') from e
        except openai.RateLimitError as e:
            raise RateLimitError from e
        except openai.AuthenticationError as e:
            logger.error(
                f'OpenAI Authentication Error: {e}. Please verify your API key is correct.'
            )
            raise
        except Exception as e:
            # Provide more context for connection errors
            error_msg = str(e)
            if 'Connection error' in error_msg or 'connection' in error_msg.lower():
                logger.error(
                    f'Connection error communicating with OpenAI API. Please check your network connection and API key. Error: {e}'
                )
            else:
                logger.error(f'Error in generating LLM response: {e}')
            raise

    async def generate_response(
        self,
        messages: list[Message],
        response_model: type[BaseModel] | None = None,
        max_tokens: int | None = None,
        model_size: ModelSize = ModelSize.medium,
        group_id: str | None = None,
        prompt_name: str | None = None,
        *,
        attribute_extraction: bool = False,
        model: str | None = None,
    ) -> dict[str, typing.Any]:
        """Generate a response with retry logic and error handling.

        When ``attribute_extraction`` is True, prepend the shared attribute-extraction
        framing to the system message so the strict "field descriptions are not values"
        instruction reaches the model on this provider's native-structured-output path.
        """
        self._apply_attribute_extraction_preamble(messages, attribute_extraction)
        if max_tokens is None:
            max_tokens = self.max_tokens

        # Add multilingual extraction instructions
        messages[0].content += get_extraction_language_instruction(group_id)

        # Wrap entire operation in tracing span
        with self.tracer.start_span('llm.generate') as span:
            attributes = {
                'llm.provider': 'openai',
                'model.size': model_size.value,
                'max_tokens': max_tokens,
            }
            if prompt_name:
                attributes['prompt.name'] = prompt_name
            span.add_attributes(attributes)

            retry_count = 0
            last_error = None
            total_input_tokens = 0
            total_output_tokens = 0

            while retry_count <= self.MAX_RETRIES:
                try:
                    response, input_tokens, output_tokens = await self._generate_response(
                        messages,
                        response_model,
                        max_tokens,
                        model_size,
                        model=model,
                    )
                    total_input_tokens += input_tokens
                    total_output_tokens += output_tokens

                    # Record token usage
                    self.token_tracker.record(prompt_name, total_input_tokens, total_output_tokens)

                    return response
                except (RateLimitError, RefusalError):
                    # These errors should not trigger retries
                    span.set_status('error', str(last_error))
                    raise
                except (
                    openai.APITimeoutError,
                    openai.APIConnectionError,
                    openai.InternalServerError,
                ):
                    # Let OpenAI's client handle these retries
                    span.set_status('error', str(last_error))
                    raise
                except Exception as e:
                    last_error = e

                    # Don't retry if we've hit the max retries
                    if retry_count >= self.MAX_RETRIES:
                        logger.error(f'Max retries ({self.MAX_RETRIES}) exceeded. Last error: {e}')
                        span.set_status('error', str(e))
                        span.record_exception(e)
                        raise

                    retry_count += 1

                    # Construct a detailed error message for the LLM
                    error_context = (
                        f'The previous response attempt was invalid. '
                        f'Error type: {e.__class__.__name__}. '
                        f'Error details: {str(e)}. '
                        f'Please try again with a valid response, ensuring the output matches '
                        f'the expected format and constraints.'
                    )

                    error_message = Message(role='user', content=error_context)
                    messages.append(error_message)
                    logger.warning(
                        f'Retrying after application error (attempt {retry_count}/{self.MAX_RETRIES}): {e}'
                    )

            # If we somehow get here, raise the last error
            span.set_status('error', str(last_error))
            raise last_error or Exception('Max retries exceeded with no specific error')
